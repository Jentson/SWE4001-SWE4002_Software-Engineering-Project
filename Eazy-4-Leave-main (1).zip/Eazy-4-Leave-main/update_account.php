<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'ez4leave');
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the account ID is provided
if (!isset($_GET['id'])) {
    echo '<script>alert("Account ID not provided");</script>';
    echo '<script>window.location.href = "AdminMain.php";</script>';
    exit();
}

$accountId = $_GET['id'];

// Check if it's a lecturer account
$sql = "SELECT * FROM lecturer WHERE Lect_ID = '$accountId'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $accountType = 'lecturer';
    $tableName = 'lecturer';
    $attributeMap = [
        'name' => 'Lect_name',
        'email' => 'Lect_email',
        'password' => 'Lect_pass'
    ];
} else {
    // Check if it's a student account
    $sql = "SELECT * FROM students WHERE stud_id = '$accountId'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $accountType = 'student';
        $tableName = 'students';
        $attributeMap = [
            'name' => 'stud_name',
            'email' => 'stud_email',
            'password' => 'stud_pass'
        ];
    } else {
        // Account not found
        echo '<script>alert("Account not found");</script>';
        echo '<script>window.location.href = "AdminMain.php";</script>';
        exit();
    }
}

if ($accountType == "lecturer"){
    $accountKey = "Lect_ID";
} else {
    $accountKey = "stud_id";
}

$sql = "SELECT * FROM $tableName WHERE $accountKey = '$accountId'";
$result = mysqli_query($conn, $sql);

if ($result) {
    if (mysqli_num_rows($result) > 0) {
        $accountDetails = mysqli_fetch_assoc($result);
    } else {
        // Account not found
        echo '<script>alert("Account not found");</script>';
        echo '<script>window.location.href = "AdminMain.php";</script>';
        exit();
    }
} else {
    // Query execution error
    echo '<script>alert("Failed to fetch account details");</script>';
    echo '<script>window.location.href = "AdminMain.php";</script>';
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $attribute = $_POST['attribute'];
    $value = $_POST['value'];

    // Get the corresponding attribute name for the account type
    $attributeName = $attributeMap[$attribute];

    // Update the account with the provided attribute and value
    $sql = "UPDATE $tableName SET $attributeName = '$value' WHERE $accountKey = '$accountId'";

    if (mysqli_query($conn, $sql)) {
        echo '<script>alert("Account updated successfully");</script>';
        echo '<script>window.location.href = "AdminMain.php";</script>';
        exit();
    } else {
        echo '<script>alert("Failed to update account");</script>';
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Update Account</title>
</head>

<body>
    <h2>Update Account</h2>

    <form method="POST" action="">
        <div>
            <label for="attribute">Choose Attribute to Update:</label>
            <select id="attribute" name="attribute">
                <option value="name">Name</option>
                <option value="email">Email</option>
                <option value="password">Password</option>
            </select>
        </div>
        <br>
        <div>
            <label for="value">Enter New Value:</label>
            <input type="text" id="value" name="value" required>
        </div>

        <br>

        <input type="submit" value="Update">
    </form>
</body>

</html>

