-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 30, 2023 at 09:26 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.0.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ez4leaveold`
--

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `dept_ID` int(11) NOT NULL,
  `dept_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`dept_ID`, `dept_name`) VALUES
(1, 'Swinbrune University of Techno'),
(2, 'University of Hertfordshire'),
(3, 'Southern New Hampshire Univers'),
(4, 'Center of Art and Design');

-- --------------------------------------------------------

--
-- Table structure for table `leave`
--

CREATE TABLE `leave` (
  `Lv_ID` int(11) NOT NULL,
  `stud_ID` varchar(15) NOT NULL,
  `Lect_ID` int(5) NOT NULL,
  `Subj_ID` varchar(10) NOT NULL,
  `LV_Date` date NOT NULL,
  `LV_Time` time(6) NOT NULL,
  `LV_reason` longtext NOT NULL,
  `LV_Docs` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `lecturer`
--

CREATE TABLE `lecturer` (
  `Lect_ID` int(5) NOT NULL,
  `Lect_name` varchar(40) NOT NULL,
  `Lect_email` varchar(40) NOT NULL,
  `Lect_pass` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `lecturer`
--

INSERT INTO `lecturer` (`Lect_ID`, `Lect_name`, `Lect_email`, `Lect_pass`) VALUES
(123456, 'Mohammad Faizal Alias', 'mfaizal.alias@newinti.edu.my', '123456'),
(123457, 'Shanmuga Sundram A Samy', 'shanmugas.asamy@newinti.edu.my', '123456'),
(123458, 'Chee Huei Ang', 'cheehuei.ang@newinti.edu.my', '123456'),
(123459, 'Siti Hawa Mohamed', 'sitihawa.msaid@newinti.edu.my', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `session`
--

CREATE TABLE `session` (
  `Sess_ID` int(11) NOT NULL,
  `Sess_Number` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `session`
--

INSERT INTO `session` (`Sess_ID`, `Sess_Number`) VALUES
(1, 'C1'),
(2, 'C2'),
(3, 'C3'),
(4, 'S1'),
(5, 'S2');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `stud_id` varchar(15) NOT NULL,
  `stud_name` varchar(40) NOT NULL,
  `stud_email` varchar(40) NOT NULL,
  `stud_pass` int(10) NOT NULL,
  `dept_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`stud_id`, `stud_name`, `stud_email`, `stud_pass`, `dept_ID`) VALUES
('J21035942', 'Darren Huang', 'j21035942@student.newinti.edu.my', 123456, 1),
('J21035943', 'Barry Allen', 'j21034953@student.newinti.edu.my', 123456, 1),
('J21035944', 'Cindy Smith', 'j21035944@student.newinti.edu.my', 123456, 2),
('J21035945', 'Aloysius Phang', 'j21035945@student.newinti.edu.my', 123456, 3);

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `Subj_ID` varchar(10) NOT NULL,
  `Subj_Name` varchar(40) NOT NULL,
  `Lect_Id` int(10) NOT NULL,
  `Sess_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`Subj_ID`, `Subj_Name`, `Lect_Id`, `Sess_ID`) VALUES
('COS10009', 'Introduction to Programming', 123459, 1),
('COS10009', 'Introduction to Programming', 123459, 2),
('COS30019', 'Introduction to artificial intelligence', 123458, 1),
('COS30019', 'Introduction to artificial intelligence', 123458, 2),
('COS30019', 'Introduction to artificial intelligence', 123458, 3),
('ICT30001', 'E-Forensics', 123456, 1),
('SWE20001', 'Managing software projects', 123456, 1),
('TNE20002', 'Network Routing Principles', 123457, 1),
('TNE20002', 'Network Routing Principles', 123457, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`dept_ID`);

--
-- Indexes for table `leave`
--
ALTER TABLE `leave`
  ADD PRIMARY KEY (`Lv_ID`),
  ADD KEY `stud_ID` (`stud_ID`,`Lect_ID`,`Subj_ID`),
  ADD KEY `Subj_ID` (`Subj_ID`),
  ADD KEY `Lect_ID` (`Lect_ID`);

--
-- Indexes for table `lecturer`
--
ALTER TABLE `lecturer`
  ADD UNIQUE KEY `Lect_id` (`Lect_ID`);

--
-- Indexes for table `session`
--
ALTER TABLE `session`
  ADD PRIMARY KEY (`Sess_ID`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`stud_id`),
  ADD KEY `dept_ID` (`dept_ID`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`Subj_ID`,`Sess_ID`),
  ADD KEY `Lect_Id` (`Lect_Id`),
  ADD KEY `Sess_ID` (`Sess_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `leave`
--
ALTER TABLE `leave`
  MODIFY `Lv_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `leave`
--
ALTER TABLE `leave`
  ADD CONSTRAINT `leave_ibfk_1` FOREIGN KEY (`stud_ID`) REFERENCES `students` (`stud_id`),
  ADD CONSTRAINT `leave_ibfk_2` FOREIGN KEY (`Subj_ID`) REFERENCES `subject` (`Subj_ID`),
  ADD CONSTRAINT `leave_ibfk_3` FOREIGN KEY (`Lect_ID`) REFERENCES `lecturer` (`Lect_ID`);

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`dept_ID`) REFERENCES `department` (`dept_ID`);

--
-- Constraints for table `subject`
--
ALTER TABLE `subject`
  ADD CONSTRAINT `subject_ibfk_1` FOREIGN KEY (`Sess_ID`) REFERENCES `session` (`Sess_ID`),
  ADD CONSTRAINT `subject_ibfk_2` FOREIGN KEY (`Lect_Id`) REFERENCES `lecturer` (`Lect_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
