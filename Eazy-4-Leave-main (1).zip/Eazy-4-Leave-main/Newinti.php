<!DOCTYPE html>
<html lang ="en">
<!--Page for ecampus-->

<head>
<meta charset="utf-8" />
<meta name ="description" content ="SWE20004" />
<meta name ="keywords" content ="HTML,CSS,Javascript" />
<meta name ="author" content ="Eazy 4 Leave" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href ="styles/style.css" rel ="stylesheet" >
<link href ="styles/responsive.css" rel ="stylesheet" >
<title>Newinti Ecampus</title>

<body id="body">
	<div>
		<div id="wrapper">
			<div id="content">
			<header>
				<img class ="e" src ="images/pic8.png" alt ="INTI Logo Newinti"/>
			</header>
				<div id="main">
					<div id="content-1" class="cssmenu">
						<ul>
							<li class="Menuheader" style="background-color: black;" ><br>STUDENTS</li>
							<li><span>NEWINTI WEBSITE</span></li>
							<li><span>INTI STUDENT EMAIL</span></li>
							<li><span>CANVAS LMS</span></li>
							<li><span>INTI DIGITAL HUB</span></li>
							<li><span>ONLINE ENROLLMENT</span></li>
							<li><a href="LeaveMainPage.php" target="_blank" style="color: white; text-decoration: none;"><span>LEAVE FORM</span></a></li>
							<li><span>CLAIMS MANAGEMENT SYSTEM</span></li>
							<li><span>LIBRARY</span></li>
							<li><span>PAST YEAR EXAM PAPERS</span></li>
							<li><span>STUDENT KIOSK - IT HELPDESK</span></li>
							<li><span>CANVAS GUIDE</span></li>
							<li><span>WIFI USER GUIDE</span></li>
							<li><span>PRINTING SERVICE</span></li>
							<li><span>MS Office For Students</span></li>
							<li><span>IICS Campus Map</span></li>
							<li><span>School of Business &amp; Communication (SBC)</span></li>
							<li><span>CENTRE FOR UH PROGRAMMES</span></li>
							<li><span>Centre For Australian Degree Programs (CADP)</span></li>
							<li><span>Center For American Education (CAE)</span></li>
							<li><span>INTI Center of Art &amp; Design (ICAD)</span></li>
							<li><span>Student Services Department (SSD)</span></li>
							<li><span>Scholarship Repository</span></li>
							<li><span>Graduation</span></li>
						</ul> 
					</div>
					<div id="content-2">
						<div id="content-2-1">
							<div id="Div3" style="margin-left:34px;margin-top:1px; height: auto; max-width: 100%;">
								<img src="images/pic9.png" alt="Welcome to ecampus portal">
							</div>
							<div id="Div1" style="margin-left:34px;margin-top:1px; margin-right: 50px; height: auto; max-width: 100%;">
								<img src="images/pic6.png" alt="Click here to INTI digital hub">
							</div>
							<div id="Div2" style="margin-left:34px;margin-top:10px; height: auto; max-width: 100%;">
								<img src="images/pic7.png" alt ="Feedback form">
							</div>
						</div>
					</div>
					<div id="footer">Copyright (C) 2022 INTI International University &amp; Colleges. All rights reserved.</div>
				</div>
			</div>
		</div>
	</div>
	
</body>
</html>
