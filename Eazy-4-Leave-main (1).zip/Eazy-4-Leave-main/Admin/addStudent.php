<!DOCTYPE html>
<html>

<head>
    <title>Admin Main Page</title>
</head>
<body>
	<header>
		<img class ="b" src ="images/pic5.png" alt ="INTI Logo" />
		<h1>Adding Student</h1>
	</header>

    <form method="POST" action="">
    <p>
        <label for="staff_id">Student ID:  </label>
        <input type="number"  placeholder="1111"  name="stud_id" required/>	
    </p>

    <p>
        <label for="staff_name">Student Name:  </label>
        <input type="text"  placeholder="Bob" name="stud_name"/>
    </p>

    <p>
        <label for="staff_email">Student Email:  </label>
        <input type="email"  placeholder="abcd@gmail.com" name="stud_email"/>
    </p>

    <p>
        <label for="staff_pass">Student Password:  </label>
        <input type="password"  placeholder="Enter password" name="stud_pass" required/>
    </p>

    <p>	
        <input type ="submit" name="Add" value="Add"/>
    </p>
    </form>

    <a href="AdminMain.php">Return to Main Page</a>
</body>

</html>


<?php
// Get the form data
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
$stud_id = $_POST['stud_id'];
$stud_name = $_POST['stud_name'];
$stud_email = $_POST['stud_email'];
$password = $_POST['stud_pass'];

// Hash the password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Database connection
$conn = new mysqli('localhost', 'root', '', 'ez4leave');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Add staff details into table
$insert_query = "INSERT INTO students (stud_id, stud_name, stud_email, stud_pass) 
VALUES ('$stud_id','$stud_name', '$stud_email', '$hashed_password')";
$result = mysqli_query($conn, $insert_query);

global $result;
}

if ($result) {
        echo '<script>alert("Student Added Successfully");</script>';
    } else {
        echo '<script>alert("Fail to add Student");</script>';
    }

?>
