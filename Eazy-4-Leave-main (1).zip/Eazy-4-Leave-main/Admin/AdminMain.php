<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'ez4leave');
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];
    if ($action == 'view') {
        header("Location:view_account.php");
        exit();
    } elseif ($action == 'delete') {
        // Redirect to the delete page with the account ID
        header("Location: delete_account.php");
        exit();
    } elseif ($action == 'update') {
        // Redirect to the update page with the account ID
        header("Location: update_account.php");
        exit();
    } elseif ($action == 'addStudent') {
        header("Location: addStudent.php");
        exit();
    } elseif ($action == 'addStaff'){
        header("Location: addStaff.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Admin Main Page</title>
</head>

<body>
    <h2>Admin Dashboard</h2>
    <form method="POST" action="">
        <label>Select Action:</label>
        <br>
        <input type="radio" id="action_view" name="action" value="view" required>
        <label for="action_view">View Account Details</label>
        <br>
        <input type="radio" id="action_update" name="action" value="update" required>
        <label for="action_update">Update Account</label>
        <br>
        <input type="radio" id="action_delete" name="action" value="delete" required>
        <label for="action_delete">Delete Account</label>
        <br>
        <input type="radio" id="action_addStudent" name="action" value="addStudent" required>
        <label for="action_addStudent">Add Student Account</label>
        <br>
        <input type="radio" id="action_addStaff" name="action" value="addStaff" required>
        <label for="action_addStaff">Add Staff Account</label>
        <br><br>
        <input type="submit" value="Proceed">
    </form>
</body>

</html>
