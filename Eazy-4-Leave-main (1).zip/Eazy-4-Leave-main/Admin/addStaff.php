<!DOCTYPE html>
<html>

<head>
    <title>Admin Main Page</title>
</head>
<body>
	<header>
		<img class ="b" src ="images/pic5.png" alt ="INTI Logo" />
		<h1>Adding Staff</h1>
	</header>

    <form method="POST" action="">
    <p>
        <label for="staff_id">Staff ID:  </label>
        <input type="number"  placeholder="1111"  name="staff_id" required/>	
    </p>

    <p>
        <label for="staff_name">Staff Name:  </label>
        <input type="text"  placeholder="Bob" name="staff_name"/>
    </p>

    <p>
        <label for="staff_email">Staff Email:  </label>
        <input type="email"  placeholder="abcd@gmail.com" name="staff_email"/>
    </p>

    <p>
        <label for="staff_pass">Staff Password:  </label>
        <input type="password"  placeholder="Enter password" name="staff_pass" required/>
    </p>

    <p>	
        <input type ="submit" name="Add" value="Add"/>
    </p>
    </form>

    <a href="AdminMain.php">Return to Main Page</a>
</body>

</html>


<?php
// Get the form data
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
$staff_id = $_POST['staff_id'];
$staff_name = $_POST['staff_name'];
$staff_email = $_POST['staff_email'];
$password = $_POST['staff_pass'];

// Hash the password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Database connection
$conn = new mysqli('localhost', 'root', '', 'ez4leave');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Add staff details into table
$insert_query = "INSERT INTO lecturer (Lect_ID, Lect_name, Lect_email, Lect_pass) 
VALUES ('$staff_id','$staff_name', '$staff_email', '$hashed_password')";
$result = mysqli_query($conn, $insert_query);

    if ($result) {
        echo '<script>alert("Staff Added Successfully");</script>';
    } else {
        echo '<script>alert("Fail to add Staff");</script>';
    }
}
?>
