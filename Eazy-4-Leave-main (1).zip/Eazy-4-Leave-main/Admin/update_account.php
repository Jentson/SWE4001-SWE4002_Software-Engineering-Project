<!DOCTYPE html>
<html>

<head>
    <title>Admin Main Page</title>
</head>

<body>
    <h2>Update Account</h2>
    <form method="POST" action="">
        <label for="account_id">Enter Account ID:</label>
        <input type="text" id="account_id" name="account_id" required>
        <br>
        <div>
            <br>
            <label for="attribute">Choose Attribute to Update:</label>
            <select id="attribute" name="attribute">
                <option value="name">Name</option>
                <option value="email">Email</option>
                <option value="password">Password</option>
            </select>
        </div>
        <br>
        <div>
            <label for="value">Enter New Value:</label>
            <input type="text" id="value" name="value" required>
        </div>

        <br>

        <input type="submit" value="Update">
        <br><br>
        <a href="AdminMain.php">Return to Main Page</a>
    </form>
</body>

</html>

<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'ez4leave');
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $accountId = $_POST['account_id'];

// Check if it's a lecturer account
$sql = "SELECT * FROM lecturer WHERE Lect_ID = '$accountId'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $accountType = 'lecturer';
    $tableName = 'lecturer';
    $attributeMap = [
        'name' => 'Lect_name',
        'email' => 'Lect_email',
        'password' => 'Lect_pass'
    ];
} else {
    // Check if it's a student account
    $sql = "SELECT * FROM students WHERE stud_id = '$accountId'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $accountType = 'student';
        $tableName = 'students';
        $attributeMap = [
            'name' => 'stud_name',
            'email' => 'stud_email',
            'password' => 'stud_pass'
        ];
    } else {
        // Account not found
        echo '<script>alert("Account not found");</script>';
        exit();
    }
}

if ($accountType == "lecturer"){
    $accountKey = "Lect_ID";
} else {
    $accountKey = "stud_id";
}

$sql = "SELECT * FROM $tableName WHERE $accountKey = '$accountId'";
$result = mysqli_query($conn, $sql);

if ($result) {
    if (mysqli_num_rows($result) > 0) {
        $accountDetails = mysqli_fetch_assoc($result);
    } else {
        // Account not found
        echo '<script>alert("Account not found");</script>';
        exit();
    }
} else {
    // Query execution error
    echo '<script>alert("Failed to fetch account details");</script>';
    exit();
}
}
// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $attribute = $_POST['attribute'];
    $value = $_POST['value'];

    // Get the corresponding attribute name for the account type
    $attributeName = $attributeMap[$attribute];

    // Update the account with the provided attribute and value
    $sql = "UPDATE $tableName SET $attributeName = '$value' WHERE $accountKey = '$accountId'";

    if (mysqli_query($conn, $sql)) {
        echo '<script>alert("Account updated successfully");</script>';
        exit();
    } else {
        echo '<script>alert("Failed to update account");</script>';
    }
}
?>


