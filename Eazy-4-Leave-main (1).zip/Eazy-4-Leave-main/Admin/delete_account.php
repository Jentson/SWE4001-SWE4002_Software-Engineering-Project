<!DOCTYPE html>
<html>
<head>
    <title>Admin Main Page</title>
</head>

<body>
    <h2>Delete Account</h2>
    <form method="POST" action="">
        <label for="account_id">Enter Account ID:</label>
        <input type="text" id="account_id" name="account_id" required>
        <br><br>
        <input type="submit" value="Delete">
        <br>
        <a href="AdminMain.php">Return to Main Page</a>
    </form>
</body>
</html>

<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'ez4leave');
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $accountId = $_POST['account_id'];

// Check if it's a lecturer account
$sql = "SELECT * FROM lecturer WHERE Lect_ID = '$accountId'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // Delete the lecturer account
    $sql = "DELETE FROM lecturer WHERE Lect_ID = '$accountId'";
    if (mysqli_query($conn, $sql)) {
        echo '<script>alert("Lecturer account deleted successfully");</script>';
    } else {
        echo '<script>alert("Failed to delete lecturer account");</script>';
    }
    exit();
}

// Check if it's a student account
$sql = "SELECT * FROM students WHERE stud_id = '$accountId'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // Delete the student account
    $sql = "DELETE FROM students WHERE stud_id = '$accountId'";
    if (mysqli_query($conn, $sql)) {
        echo '<script>alert("Student account deleted successfully");</script>';
    } else {
        echo '<script>alert("Failed to delete student account");</script>';
    }
    exit();
}
}

?>
