<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'ez4leave');
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $accountId = $_POST['account_id'];
    $action = $_POST['action'];

    if ($action == 'view') {
        // Retrieve and display account details
        $accountDetails = getAccountDetails($accountId);

        if ($accountDetails != null) {
            echo '<div>';
            echo '<h4>Account Details</h4>';
            echo '<p>ID: ' . $accountDetails['id'] . '</p>';
            echo '<p>Name: ' . $accountDetails['name'] . '</p>';
            echo '<p>Email: ' . $accountDetails['email'] . '</p>';
            echo '<p>Role: ' . $accountDetails['type'] . '</p>';
            echo '</div>';
        } else {
            echo '<script>alert("Account not found");</script>';
        }
    } elseif ($action == 'delete') {
        // Redirect to the delete page with the account ID
        header("Location: delete_account.php?id=$accountId");
        exit();
    } elseif ($action == 'update') {
        // Redirect to the update page with the account ID
        header("Location: update_account.php?id=$accountId");
        exit();
    }
}

// Function to retrieve account details
function getAccountDetails($accountId)
{
    global $conn;

    // Check if it's a lecturer account
    $sql = "SELECT * FROM lecturer INNER JOIN roles ON lecturer.Role_id = roles.role_id
    WHERE Lect_ID = '$accountId'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $details = [
            'id' => $row['Lect_ID'],
            'name' => $row['Lect_name'],
            'email' => $row['Lect_email'],
            'type' => $row['role_name'],
        ];
        return $details;
    }

    // Check if it's a student account
    $sql = "SELECT * FROM students WHERE stud_id = '$accountId'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $details = [
            'id' => $row['stud_id'],
            'name' => $row['stud_name'],
            'email' => $row['stud_email'],
            'type' => 'Student'
        ];
        return $details;
    }

    // Account not found
    return null;
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Admin Main Page</title>
</head>

<body>
    <h2>Admin Main Page</h2>

    <form method="POST" action="">
        <label for="account_id">Enter Account ID:</label>
        <input type="text" id="account_id" name="account_id" required>
        <br><br>
        <label>Select Action:</label>
        <br>
        <input type="radio" id="action_view" name="action" value="view" required>
        <label for="action_view">View Account Details</label>
        <br>
        <input type="radio" id="action_update" name="action" value="update" required>
        <label for="action_update">Update Account</label>
        <br>
        <input type="radio" id="action_delete" name="action" value="delete" required>
        <label for="action_delete">Delete Account</label>
        <br><br>
        <input type="submit" value="Submit">
    </form>
</body>

</html>
