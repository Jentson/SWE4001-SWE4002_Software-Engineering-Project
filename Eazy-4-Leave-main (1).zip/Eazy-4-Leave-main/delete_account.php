<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'ez4leave');
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the account ID is provided
if (!isset($_GET['id'])) {
    echo '<script>alert("Account ID not provided");</script>';
    echo '<script>window.location.href = "AdminMain.php";</script>';
    exit();
}

$accountId = $_GET['id'];

// Check if it's a lecturer account
$sql = "SELECT * FROM lecturer WHERE Lect_ID = '$accountId'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // Delete the lecturer account
    $sql = "DELETE FROM lecturer WHERE Lect_ID = '$accountId'";
    if (mysqli_query($conn, $sql)) {
        echo '<script>alert("Lecturer account deleted successfully");</script>';
    } else {
        echo '<script>alert("Failed to delete lecturer account");</script>';
    }
    echo '<script>window.location.href = "AdminMain.php";</script>';
    exit();
}

// Check if it's a student account
$sql = "SELECT * FROM students WHERE stud_id = '$accountId'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // Delete the student account
    $sql = "DELETE FROM students WHERE stud_id = '$accountId'";
    if (mysqli_query($conn, $sql)) {
        echo '<script>alert("Student account deleted successfully");</script>';
    } else {
        echo '<script>alert("Failed to delete student account");</script>';
    }
    echo '<script>window.location.href = "AdminMain.php";</script>';
    exit();
}

// Account not found
echo '<script>alert("Account not found");</script>';
echo '<script>window.location.href = "AdminMain.php";</script>';
exit();
?>
